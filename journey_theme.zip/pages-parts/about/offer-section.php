
<!--Drugi deo strane, ispod AGENCY profile, repeater je za stavke ispod-->

<div class="grid_9">
        <h3 class="head1"><?php the_field('offer_title')?></h3>
        <p class="text1 tx2"><?php the_field('offer_text')?></p>
   <ul class="list2">
    <?php if ( have_rows('ponuda_repeater') ) : ?>
  
            <?php while( have_rows('ponuda_repeater') ) : the_row();
                $offer_field = get_sub_field('offer_field');
            ?>
            <li>
                <a href="#"><?php echo $offer_field?></a>
            </li>
            <?php endwhile; ?>
 
    <?php endif; ?>
   </ul>
  <div class="clear"></div>
</div><!--rnd grid_9-->