
<!--Prvi deo strane sa slikom i opisom-->

<div class="grid_9">
    <?php 
    $profile_title    = get_field('profile_title');
    $profile_image    = get_field('profile_image');
    $profile_subtitle = get_field('profile_subtitle');
    $profile_content  = get_field('profile_content');
    ?>

        <div class="">
          <h3><?php echo $profile_title?></h3>
          <img src="<?php echo $profile_image['url']?>" 
               alt="<?php echo $profile_image['alt']?>">
          <p class="text1">
            <a href="#"><?php echo $profile_subtitle?></a></p>
          <p><?php echo $profile_content?></p>
          <div class="clear"></div>
           </div>
</div><!--end grid_9-->
