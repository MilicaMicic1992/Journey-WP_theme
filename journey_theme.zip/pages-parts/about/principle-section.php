
<!--Deo sa stavkama sa desne strane ''Principi', repeater za stavke ispod->

<div class="grid_3">
<h3><?php the_field('principles_title')?></h3>

 <?php if ( have_rows('principles_repeater') ) : ?>

    <ul class="list1">

    <?php while( have_rows('principles_repeater') ) : the_row();
    $principles_number   = get_sub_field('principles_number');
    $principles_subtitle = get_sub_field('principles_subtitle');
    $principles_text     = get_sub_field('principles_text');
    ?>
          <li>
            <div class="count"><?php echo $principles_number?></div>
            <div class="extra_wrapper">
              <div class="text1"><a href="#"><?php echo $principles_subtitle?></a></div>
              <?php echo $principles_text?> </div>
          </li>
    <?php endwhile; ?>
    </ul>
  <?php endif; ?>
</div><!--end grid_3-->