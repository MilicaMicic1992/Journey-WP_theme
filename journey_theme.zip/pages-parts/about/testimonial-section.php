
<!--Custom post napravljen sa kategorijom 'testimonial'-->

<div class="grid_3">
<?php
//prikaz postova iz kategorije "Testimonial"
      $args = array(
          'post_type' => 'testimonial_post', //slug prilagođenog posta
          'category_name' => 'testimonials', // kategorija
          'posts_per_page' => 2, // Broj postova za prikaz
      );
      query_posts( $args );
      // Uključite template za pojedinačne postove
      while ( have_posts() ) : the_post();
          get_template_part( 'single-testimonial_post' ); // Uključi odgovarajući template za pojedinačne postove
      endwhile;
      // Resetirajte upit
      wp_reset_query();
      ?>
      </div>

      