
<!--Deo sa stavkama ispod Newslettera, sidebar sa desne strane, sa plavim strelicama-->

<div class="grid_4">

    <?php
    $newsletter_title   = get_field('newsletter_title');
    $success_newsletter = get_field('success_newsletter');
    $sign_up_newsletter = get_field('sign_up_newsletter');
    $error_newsletter   = get_field('error_newsletter');
    ?>

        <div class="newsletter_title"><?php echo $newsletter_title;?></div>
        <div class="n_container">
          <form id="newsletter" action="#">
            <div class="success"><?php echo $success_newsletter;?></div>
            <div class="text1"><?php echo $sign_up_newsletter;?></div>
            <label class="email">
              <input type="email" value="email address" >
              <span class="error">*<?php echo $error_newsletter;?></span></label>
            <div class="clear"></div>
            <a href="#" class="" data-type="submit"></a>
          </form>
          <ul class="list">
                    <?php if ( have_rows('newsletter-repeater') ) : ?>

                        <?php while( have_rows('newsletter-repeater') ) : the_row(); 

                        $newsletter_item = get_sub_field('newsletter_item');
                        ?>
                        <li><a href="#"><?php echo $newsletter_item;?></a></li>
                        

                        <?php endwhile; ?>

                    <?php endif; ?>
          </ul>
        </div><!--end n_container-->
      </div><!--end grid_4-->
    <div class="clear"></div>