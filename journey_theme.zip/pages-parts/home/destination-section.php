
<!--Repeater za deo sa TOP destinacijama na kojima imaju efekti-->

<!--start img-boxes--> 
<div class="container_12">
      <div class="grid_12">
        <h3><?php the_field('img_box_title') ?></h3>
      </div><!--end grid_12-->
        <div class="boxes">
            <div class="grid_4">
               <?php if ( have_rows('img_box_repeater') ) : ?>    
                <?php while( have_rows('img_box_repeater') ) : the_row(); 
                        $img_box     = get_sub_field('img_box');
                        $img_title   = get_sub_field('img_title');
                        $img_content = get_sub_field('img_content');
                        $img_bttn    = get_sub_field('img_bttn');
                ?>
                        <figure>
                            <div>
                            <img src="<?php echo $img_box['url'];?>"
                                 alt="<?php echo $img_box['alt'];?>">
                            </div>
                            <figcaption>
                                <h3><?php echo $img_title?></h3>
                                <?php echo $img_content?>
                                <a href="#" class="btn"><?php echo $img_bttn?></a>
                            </figcaption>
                        </figure>                    
                <?php endwhile; ?>
                  </div><!--end grid_4-->
              <?php endif; ?>
        <div class="clear"></div>
    </div><!--end boxes-->  
<!--end img-boxes--> 
