
<!--Repeater za tabove koji sadrze informacije o destinacijama-->
<div class="grid_8">
  <div id="tabs">
    <?php if ( have_rows('tabs_repeater') ) : ?>
          <ul>
      <?php while( have_rows('tabs_repeater') ) : the_row();      
          $tab_name = get_sub_field('tab_name');
      ?>
          <li>
            <a href="#tabs-1"><?php echo $tab_name;?></a>
          </li>        
      <?php endwhile; ?>
          </ul>
    <?php endif; ?>
      

<!--Prikaz postova iz kategorije "Ponude"-->
  <?php
      $args = array(
          'post_type' => 'offer_post', // Slag prilagodjenog posta
          'category_name' => 'last minute', // Kategorija
          'posts_per_page' => 2, // Broj postova za prikaz
      );
      query_posts( $args );
      // Uključite template za pojedinačne postove
      while ( have_posts() ) : the_post();
          get_template_part( 'single-offer_post' ); // Uključi odgovarajući template za pojedinačne postove
      endwhile;
      // Reset upita
      wp_reset_query();
  ?>
            <div class="clear "></div>
      </div><!--end extra_wrapper-->
    </div><!--end tab_cont-->
  </div><!--end tabs-->
</div><!--end grid_8-->
