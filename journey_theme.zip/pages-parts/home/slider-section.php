

<!--Slajder na vrhu stranice, mi smo menjali sa Siema sliderom-->

<!--start slider -->
<?php if ( have_rows('slider_images') ) : ?>

  <div class="container_12">
    <div class="grid_12">
      <div class="slider-relative">
        <div class="slider-block">
          <div class="slider"> 
              <a href="#" class="prev"></a>
              <a href="#" class="next"></a>
            <ul class="siema">
              
               <?php while( have_rows('slider_images') ) : the_row(); ?>

                        <?php 
                        $slider_image     = get_sub_field('slider_image');
                        $title_first_row  = get_sub_field('title_first_row');
                        $title_second_row = get_sub_field('title_second_row');
                        ?>
                <li>
                        <img   src="<?php echo $slider_image['url'];?>" 
                               alt="<?php echo $slider_image['alt'];?>">
                        <div class="banner">
                            <div><?php echo $title_first_row;?></div>
                            <br>
                            <span><?php echo $title_second_row;?></span>
                        </div><!--end banner-->
                </li>        
              <?php endwhile; ?>
            </ul>
          </div><!--end slider-->
        </div><!--end slider-block-->
      </div><!--end slider-relative-->
    </div><!--end  grid_12-->
  </div><!--end container_12-->
  <?php endif; ?>
<!--end  slider -->
