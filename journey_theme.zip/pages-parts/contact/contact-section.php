
<?php
$contact_us = get_field('contact_us');

?>

<div class="grid_3">
        <h3><?php echo $contact_us;?></h3>
        <form id="form" action="#">
          <div class="success_wrapper">
            <div class="success">Contact form submitted!<br>
              <strong>We will be in touch soon.</strong> </div>
          </div>
          <fieldset>
            <label class="name">
              <input type="text" value="Name">
              <br class="clear">
              <span class="error error-empty">*This is not a valid name.</span><span class="empty error-empty">*This field is required.</span> </label>
            <label class="email">
              <input type="text" value="Email">
              <br class="clear">
              <span class="error error-empty">*This is not a valid email address.</span><span class="empty error-empty">*This field is required.</span> </label>
            <label class="name">
              <input type="text" value="Subject">
              <br class="clear">
              <span class="error error-empty">*This is not a valid subject.</span><span class="empty error-empty">*This field is required.</span> </label>
            <label class="message">
              <textarea>Message</textarea>
              <br class="clear">
              <span class="error">*The message is too short.</span> <span class="empty">*This field is required.</span> </label>
            <div class="clear"></div>
            <div class="btns"><a data-type="reset" class="btn">Clear</a>
              <div class="none"></div>
              <a data-type="submit" class="btn">Send</a>
              <div class="clear"></div>
            </div>
          </fieldset>
        </form>
      </div><!--end grid_3-->