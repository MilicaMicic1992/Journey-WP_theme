<?php
$address    = get_field('address');
$freephone  = get_field('freephone');
$telephone  = get_field('telephone');
$fax        = get_field('fax');
$email      = get_field('email');
?>

<div class="grid_9">
        <h3>Stay in Touch</h3>
        <div class="map">
          <figure class="img_inner fleft">
            <iframe src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Brooklyn,+New+York,+NY,+United+States&amp;aq=0&amp;sll=37.0625,-95.677068&amp;sspn=61.282355,146.513672&amp;ie=UTF8&amp;hq=&amp;hnear=Brooklyn,+Kings,+New+York&amp;ll=40.649974,-73.950005&amp;spn=0.01628,0.025663&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe>
          </figure>
          <address>
          <dl>
            <dt> <?php echo $address;?> </dt>
            <dd><span>Freephone:</span><?php echo $freephone;?></dd>
            <dd><span>Telephone:</span><?php echo $telephone;?></dd>
            <dd><span>FAX:</span><?php echo $fax;?></dd>
            <dd>E-mail: <a href="#" class="link-1"><?php echo $email;?></a></dd>
          </dl>
          </address>
        </div>
      </div><!--end grid_9-->