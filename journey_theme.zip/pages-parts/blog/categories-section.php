
<?php 
$categories_title = get_field('categories_title');
?>
<h3><?php echo $categories_title ?></h3>

<!--Repeater za stavke ispod naslova CATEGORIES, oznacene strelicama-->

<?php if ( have_rows('categories_repeater') ) : ?>

    <ul class="list2 l1">

    <?php while( have_rows('categories_repeater') ) : the_row();
        $categories_item = get_sub_field('categories_item');
    ?>
        <li>
            <a href="#"><?php echo $categories_item;?></a>
        </li>
    <?php endwhile; ?>
    </ul>
<?php endif; ?>


        
          
          
       