
<?php 
$archive_title = get_field('archive_title');
?>
<h3><?php echo $archive_title ?></h3>

<!--Repeater za stavke ispod naslova ARCHIVE, oznacene strelicama-->

<?php if ( have_rows('archive_repeater') ) : ?>

    <ul class="list2 l1">

    <?php while( have_rows('archive_repeater') ) : the_row();
        $categories_item = get_sub_field('archive_item');
    ?>
        <li>
            <a href="#"><?php echo $archive_item;?></a>
        </li>
    <?php endwhile; ?>
    </ul>
<?php endif; ?>

