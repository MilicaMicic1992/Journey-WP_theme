

<!--Browse sekcija koja se nalazi u sidebaru sa desne strane -->

<?php 
$browse_title    = get_field('browse_title');
$browse_operator = get_field('browse_operator');
$browse_value    = get_field('browse_value');
?>

<h3><?php echo $browse_title;?></h3>
        <form method="post" id="form1" class="form1" action="#">
          <label class="mb0"> <span><?php echo $browse_operator;?></span>
            <select name="select">
              <option value=""><?php echo $browse_value;?></option>
              <option value="">...</option>
            </select>
          </label>
          <div class="clear"></div>
          <a onClick="document.getElementById('form1').submit()" href="#" class="btn"> Search</a>
        </form>

