

<!--Search sekcija koja se nalazi u sidebaru sa desne strane-->

<?php 
$search_title           = get_field('search_title');
$search_operators       = get_field('search_operators');
$search_destination     = get_field('search_destination');
$search_departing       = get_field('search_departing');
$search_price           = get_field('search_price');
$search_duration        = get_field('search_duration');

?>

<h3><?php echo $search_title;?></h3>
        <form method="post" id="form2" class="form1" action="#">
          <label > <span><span class="col1"><?php echo $search_operators;?></span><br>
          <?php echo $search_destination;?></span>
            <select name="select">
              <option value="">Any destination</option>
              <option value="">...</option>
            </select>
          </label>
          <label > <span><?php echo $search_departing;?></span>
            <select name="select">
              <option value="">Any departing</option>
              <option value="">...</option>
            </select>
          </label>
          <label> <span><?php echo $search_price;?></span>
            <select name="select">
              <option value="">Any price</option>
              <option value="">...</option>
            </select>
          </label>
          <label class="mb0"> <span><?php echo $search_price;?></span>
            <select name="select">
              <option value="">Any duration</option>
              <option value="">...</option>
            </select>
          </label>