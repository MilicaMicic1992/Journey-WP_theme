<?php
get_header();
?>
<?php
the_title();
?>

<?php  
  $blog_title = get_field('blog_title');
  $time       = get_field('time');
  $blog_title = get_field('blog_title');
  $name       = get_field('name');
  $post_img   = get_field('post_img');
  $post_text  = get_field('post_text');
  $post_bttn  = get_field('post_bttn');

?>

<h3><?php echo $blog_title  ;?></h3>
<div class="blog">
          <time datetime="2045-01-01">
            <?php echo $time;?>
            </time>
          <div class="extra_wrapper">
            <div class="text1 upp"> <?php echo $blog_title;?></div>
            <div class="links">Posted by<a href="#"> <?php echo $name;?></a><a href="#" class="comment">
            0 Comment(s)</a></div>
          </div>
          <div class="clear"></div>
          <img src="<?php echo $post_img['url'];?>" 
               alt="<?php echo $post_img['alt'];?>" 
               class="img_inner fleft">
          <div class="extra_wrapper">
            <p class="text1"><?php echo $post_text;?></p> 
            <a href="#" class="btn"><?php echo $post_bttn;?></a> </div>
        </div><!--end blog-->




<?php get_footer();?>



