<?php

$tours_title        = get_field('tours_title');
$tours_image        = get_field('tours_image');
$tours_subtitle     = get_field('tours_subtitle');
$tours_text_first   = get_field('tours_text_first');
$tours_price_first  = get_field('tours_price_first');
$tours_text_second  = get_field('tours_text_second');
$tours_price_second = get_field('tours_price_second');
?>
<?php echo $tours_title;?>
<div class="grid_9">
        <h3><?php echo $tours_title;?></h3>
        <div class="tours">
          <div class="grid_4 alpha">
            <div class="tour"> 
                <img src="<?php echo $tours_image['url'];?>" 
                     alt="<?php echo $tours_image['alt'];?>" 
                     class="img_inner fleft">
              <div class="extra_wrapper">
                <p class="text1"><?php echo $tours_subtitle;?></p>
                <p class="price"><?php echo $tours_text_first;?><span>From $<?php echo $tours_price_first;?></span></p>
                <p class="price"><?php echo $tours_text_second;?><span>From $<?php echo $tours_price_second;?></span></p>
                <a href="#" class="btn">Details</a> </div>
            </div>
          </div><!--end grid_4 alpha-->
        </div><!--end tours-->
      </div><!--end grid_9-->