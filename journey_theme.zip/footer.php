

</div><!--end main-->  

<script>
  // Sačekajte da se dokument učita
  document.addEventListener("DOMContentLoaded", function () {
    // Izaberite element sa klasom "siema"
    const siemaElement = document.querySelector(".siema");

    // Inicijalizujte Siema.js
    const siema = new Siema({
      selector: siemaElement,
      loop: true,  // Omogućava loop slajdera
      duration: 1000,  // Vreme trajanja svakog slajda u milisekundama
      onChange: function () {
        // Ova funkcija se poziva pri svakoj promeni slajda
        // Možete dodati dodatnu logiku ili promene ovde
      },
    });

    // Automatski loop slajdera
    setInterval(() => {
      siema.next();  // Prebaci se na sledeći slajd
    }, 3000);  // Promena svakih 3 sekunde (podesite prema potrebi)
  });
</script>


<!--
<div class="main">

<div class="bottom_block">
    <div class="container_12">
      <div class="grid_2 prefix_2">

       <?php if ( have_rows('bttn-block-repeater') ) : ?>
        <ul>
        <?php while( have_rows('bttn-block-repeater') ) : the_row();
        $bttn_block = get_sub_field('bttn_block');
        ?>
         <li><a href="#"><?php echo $bttn_block;?></a></li>
        <?php endwhile; ?>
        </ul>
      <?php endif; ?>
      </div> 
         
      <div class="clear"></div>
    </div><!--end container_12-->
  </div><!--end bottom_block-->
</div>




<footer>
  <div class="container_12">
    <div class="grid_12">
      <div class="socials"> <a href="#"></a> <a href="#"></a> <a href="#"></a> <a href="#"></a> </div>
      <div class="copy"> Journey &copy; 2045 | <a href="#">Privacy Policy</a> | Design by: <a href="http://www.templatemonster.com/">TemplateMonster.com</a> </div>
    </div>
    <div class="clear"></div>
  </div>
</footer>

      <?php wp_footer(); ?>
      
   </body>
</html>