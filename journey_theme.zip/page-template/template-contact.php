<?php
/*
Template name: Contact
*/ 
get_header();
?>
<div class="main">
  <div class="content">
    <div class="container_12">

    <?php get_template_part('pages-parts/contact/info-section');?>
    <?php get_template_part('pages-parts/contact/contact-section');?>


    </div><!--end container_12-->
   </div><!--end content-->
</div><!--end main-->


<?php get_footer();?>