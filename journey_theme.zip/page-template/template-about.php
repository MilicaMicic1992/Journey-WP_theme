<?php
/*
Template name: About
*/ 
get_header();
?>
<div class="main">
  <div class="content">
  <div class="container_12">


  <?php get_template_part('pages-parts/about/profile-section');?>
  <?php get_template_part('pages-parts/about/principle-section');?>
  <?php get_template_part('pages-parts/about/testimonial-section');?>
  <?php get_template_part('pages-parts/about/offer-section');?>

</div><!--end container_12-->
</div><!--end content-->
</div><!--end main-->


<?php get_footer();?>
