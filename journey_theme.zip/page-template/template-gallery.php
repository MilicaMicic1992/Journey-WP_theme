<?php
/*
Template name: Gallery
*/ 
get_header();
?>
    
    <!--Custom post za galeriju-->

        <?php
// Prikaz postova iz kategorije "Galerija"
      $args = array(
          'post_type' => 'gallery_post', // Slug prilagođenog posta
          'category_name' => 'galerija', // kategorija
          'posts_per_page' => -1, // Broj postova za prikaz
      );
      query_posts( $args );
      // Uključite template za pojedinačne postove
      while ( have_posts() ) : the_post();
          get_template_part( 'single-gallery_post' ); // Uključi odgovarajući template za pojedinačne postove
      endwhile;
      // Resetirajte upit
      wp_reset_query();
      ?>
      
    
<?php get_footer();?>