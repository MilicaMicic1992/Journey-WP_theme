<?php
/*
Template name: Blog
*/ 
get_header();
?>
<div class="main">
  <div class="content">
    <div class="container_12">

<!--Ovde ide kod za post koji je napraavljen u single.php-->


<!--Ovde se ukljucuju delovi koji se nalaze u sidebaru-->
<div class="grid_3">
    <?php get_template_part('pages-parts/blog/categories-section');?>
    <?php get_template_part('pages-parts/blog/archive-section');?>
</div>

<div class="clear"></div>
        </div><!--end container_12-->
    </div><!--end content-->
</div><!--end main-->

<?php get_footer();?>