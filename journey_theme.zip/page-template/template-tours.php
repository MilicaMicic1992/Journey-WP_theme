<?php
/*
Template name: Tours
*/ 
get_header();
?>

<div class="main">
    <div class="content">
        <div class="container_12">
<!--Custom post za Ture-->
        <?php
//Prikaz postova iz kategorije "Tours"
      $args = array(
          'post_type' => 'tours_post', // Slug prilagođenog posta
          'category_name' => 'tours', // Kategorija
          'posts_per_page' => -1, // Broj postova za prikaz
      );
      query_posts( $args );
      // Uključite template za pojedinačne postove
      while ( have_posts() ) : the_post();
          get_template_part( 'single-tours_post' ); // Uključi odgovarajući template za pojedinačne postove
      endwhile;
      // Resetirajte upit
      wp_reset_query();
      ?>

<div class="grid_3">

        <?php get_template_part('pages-parts/tours/browse-section');?>
        <?php get_template_part('pages-parts/tours/search-section');?>
        
<div class="clear"></div>
</div>

        </div><!--end container_12-->
    </div><!--end content-->
</div><!--end main-->



<?php get_footer();?>