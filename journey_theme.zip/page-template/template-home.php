<?php
/*
Template name: Home page
*/ 
get_header();
?>


<div class="main">

<?php get_template_part('pages-parts/home/slider-section');?>

  <div class="content">
    <div class="container_12">

      <?php get_template_part('pages-parts/home/destination-section');?>
      <?php get_template_part('pages-parts/home/information-section');?>
      <?php get_template_part('pages-parts/home/newsletter-section');?>

    </div><!--end container_12-->
  </div><!--end content--> 
</div><!--end main-->


<?php get_footer();?>