<?php
get_header();
?>
<?php
the_title();
?>
<div class="clear"></div>
<?php 
$post_title = get_field ('post_title');
$post_text  = get_field ('post_text');
$post_img   = get_field ('post_img');
$post_bttn  = get_field ('post_bttn');

?>
    <div class="clear"></div>
    <div class="tab_cont" >
          <img src="<?php echo $post_img['url'];?>"
                     alt="<?php echo $post_img['alt'];?>"> 
                <div class="extra_wrapper">
                <div class="text1"><?php echo $post_title;?></div>
                <p class="style1"><a class="col2" href="#">Click here</a><?php echo $post_text;?></p>
                <a href="#" class="btn"><?php echo $post_bttn;?></a>
                <div class="clear "></div>
                </div>
             
    </div>


