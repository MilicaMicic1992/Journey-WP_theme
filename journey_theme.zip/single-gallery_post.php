<?php
get_header();
?>
<?php
the_title();
?>
<div class="main">
  <div class="content">

    <div class="container_12">
        <?php
            $gallery_title = get_field('gallery_title');
            $gallery_image = get_field('gallery_image');
        ?>
          <div class="grid_12">
        <h3><?php echo $gallery_title;?></h3>
      </div>
      <div class="clear"></div>
      <div class="gallery">
        <div class="grid_4"> 
            <a href="images/big1.jpg" class="gal img_inner">
                <img src="<?php echo $gallery_image['url'];?>"
                     alt="<?php echo $gallery_image['alt'];?>"
                >
            </a>
        </div> <!--end grid_4-->
      </div><!--end gallery-->
      <div class="clear"></div>
    </div><!--end container_12-->
  </div><!--end content-->
</div><!--end main-->


<?php get_footer();?>