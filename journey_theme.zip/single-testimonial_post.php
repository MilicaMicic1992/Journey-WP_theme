<?php
get_header();
?>
<?php
the_title();
?>

<div class="grid_3">

<?php 
$testimonial_title        = get_field('testimonial_title');
$testimonial_content      = get_field('testimonial_content');
$testimonial_manager_name = get_field('testimonial_manager_name');
?>
        <h3 class="head1"><?php echo $testimonial_title?></h3>
        <blockquote>
          <p class="text1"><?php echo $testimonial_content?></p>
          <div class="bq_bot">
            <div class="text1"><?php echo $testimonial_manager_name?></div>
         
        </blockquote>
</div><!--end grid_3-->