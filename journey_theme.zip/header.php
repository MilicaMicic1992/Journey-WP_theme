<!--
 **********************************************
 * Project: Journey site
 **********************************************
 * Developed by:
   + design: Milica Micic
   + e-mail: <milica.maksimovic0922@gmail.com>
   + html, css, vanilla js & php
   + responsive page
 *********************************************
-->

<!DOCTYPE html>
<html <?php language_attributes ();?>>
   <head>
      <!-- basic -->
      <meta charset="<?php bloginfo(' charset '); ?>">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title><?php wp_title();?> </title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">     
      <?php wp_head(); ?>
      
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body class="page1" <?php body_class();?>>
<header>
  <div class="container_12">
    <div class="grid_12">
      <h1><a href="index.html"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt=""></a></h1>
      <div class="clear"></div>
    </div>
    <div>
        <nav>
         <ul>
          <?php
            $menu_args = array(
                  'theme_location'  => 'header_menu',
                  'container_class' => 'menu_block',
                  'menu_class'      => 'sf-menu',
                  'depth'           => '2',     
                  );
               wp_nav_menu($menu_args);
            ?>
         </ul>    
        </nav>
        
      <div class="clear"></div>
      </div>
    <div class="clear"></div>
  </div>
</header>



