<?php

//////Iskljucivanje Gutenberg editora//////
    add_filter('use_block_editor_for_post', '__return_false', 10);


// obrisi default jquery koji wp ubacuje sam
function remove_default_jquery() {
    wp_deregister_script('jquery');
}
add_action('wp_enqueue_scripts', 'remove_default_jquery');


 //Install jQuery 3.4.1 - jQuery CDN
function replace_default_jquery() {
    wp_deregister_script('jquery');
    wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js', array(), null, true);
    wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'replace_default_jquery');


//////Ukljucivanje CSS i JS//////
function enqueue_custom_styles_and_scripts() {
    $theme_version = wp_get_theme()->get('Version');
    $css_directory = get_template_directory_uri() . '/assets/css/';
    $js_directory = get_template_directory_uri() . '/assets/js/';
   
    // Enqueue CSS Libraries
    wp_enqueue_style('grid', $css_directory . 'grid.css', array(), $theme_version);
    wp_enqueue_style('superfish', $css_directory . 'superfish.css', array(), $theme_version);
    wp_enqueue_style('reset', $css_directory . 'reset.css', array(), $theme_version);
    wp_enqueue_style('style', get_stylesheet_uri(), array(), $theme_version, 'all' );
    wp_enqueue_style('form', $css_directory . 'form.css', array(), $theme_version);
    wp_enqueue_style('slider', $css_directory . 'slider.css', array(), $theme_version);
    wp_enqueue_style('component', $css_directory . 'component.css', array(), $theme_version);
    wp_enqueue_style('ie', $css_directory . 'ie.css', array(), $theme_version); 
    wp_enqueue_style('touchTouch', $css_directory . 'touchTouch.css', array(), $theme_version);
   
    
    
    wp_enqueue_script('sForm', $js_directory . 'sForm.js', array('jquery'), $theme_version, true);
    wp_enqueue_script('superfish', $js_directory . 'superfish.js', array('jquery'),'1.4.8', true);  
    wp_enqueue_script('tms-0.4.1', $js_directory . 'tms-0.4.1.js', array('jquery'),'0.4.1', true);
    wp_enqueue_script('siema.min', $js_directory . 'siema.min.js', array('jquery'),'1.5.1', true);
}

add_action('wp_enqueue_scripts', 'enqueue_custom_styles_and_scripts');


 
//////Ubacivanje menija na sajt//////

    register_nav_menus( array(
        'header_menu' => 'Main menu'
    ) );

//////Registrovanje Theme setings//////

    if( function_exists('acf_add_options_page') ) {
        
        if( function_exists('acf_add_options_page') ) {
        
            acf_add_options_page(array(
                'page_title'    => 'Theme General Settings',
                'menu_title'    => 'Theme Settings',
                'menu_slug'     => 'theme-general-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ));
        
        }
    }   


// Register Custom Post Type za ponude na Home page
function offer_post_type() {

	$labels = array(
		'name'                  => _x( 'Offers', 'Post Type General Name', 'journey' ),
		'singular_name'         => _x( 'Offer', 'Post Type Singular Name', 'journey' ),
		'menu_name'             => __( 'Ponude', 'journey' ),
		'name_admin_bar'        => __( 'Post Type', 'journey' ),
		'archives'              => __( 'Item Archives', 'journey' ),
		'attributes'            => __( 'Item Attributes', 'journey' ),
		'parent_item_colon'     => __( 'Parent Item:', 'journey' ),
		'all_items'             => __( 'All Items', 'journey' ),
		'add_new_item'          => __( 'Add New Item', 'journey' ),
		'add_new'               => __( 'Add New', 'journey' ),
		'new_item'              => __( 'New Item', 'journey' ),
		'edit_item'             => __( 'Edit Item', 'journey' ),
		'update_item'           => __( 'Update Item', 'journey' ),
		'view_item'             => __( 'View Item', 'journey' ),
		'view_items'            => __( 'View Items', 'journey' ),
		'search_items'          => __( 'Search Item', 'journey' ),
		'not_found'             => __( 'Not found', 'journey' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'journey' ),
		'featured_image'        => __( 'Featured Image', 'journey' ),
		'set_featured_image'    => __( 'Set featured image', 'journey' ),
		'remove_featured_image' => __( 'Remove featured image', 'journey' ),
		'use_featured_image'    => __( 'Use as featured image', 'journey' ),
		'insert_into_item'      => __( 'Insert into item', 'journey' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'journey' ),
		'items_list'            => __( 'Items list', 'journey' ),
		'items_list_navigation' => __( 'Items list navigation', 'journey' ),
		'filter_items_list'     => __( 'Filter items list', 'journey' ),
	);
	$args = array(
		'label'                 => __( 'Offer', 'journey' ),
		'description'           => __( 'Custom post za offers', 'journey' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'offer_post', $args );

}
add_action( 'init', 'offer_post_type', 0 );

//Register custom post type za testimonialse na About stranici 

// Register Custom Post Type
function testimonial_post_type() {

	$labels = array(
		'name'                  => _x( 'Testimonials', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Testimonial', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Testimonials', 'text_domain' ),
		'name_admin_bar'        => __( 'Post Type', 'text_domain' ),
		'archives'              => __( 'Item Archives', 'text_domain' ),
		'attributes'            => __( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
		'all_items'             => __( 'All Items', 'text_domain' ),
		'add_new_item'          => __( 'Add New Item', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$args = array(
		'label'                 => __( 'Testimonial', 'journey' ),
		'description'           => __( 'Custom post za testiomonials', 'journey' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'testimonial_post', $args );

}
add_action( 'init', 'testimonial_post_type', 0 );


//Register custom post type za galeriju


// Register Custom Post Type
function gallery_post_type() {

	$labels = array(
		'name'                  => _x( 'Galleries', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Gallery', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Galerija', 'text_domain' ),
		'name_admin_bar'        => __( 'Post Type', 'text_domain' ),
		'archives'              => __( 'Item Archives', 'text_domain' ),
		'attributes'            => __( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
		'all_items'             => __( 'All Items', 'text_domain' ),
		'add_new_item'          => __( 'Add New Item', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$args = array(
		'label'                 => __( 'Gallery', 'text_domain' ),
		'description'           => __( 'Custom post za galeriju', 'journey' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'gallery_post', $args );

}
add_action( 'init', 'gallery_post_type', 0 );


//Register custom post type za ture

// Register Custom Post Type
function tours_post_type() {

	$labels = array(
		'name'                  => _x( 'Tours', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Tour', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Ture', 'text_domain' ),
		'name_admin_bar'        => __( 'Post Type', 'text_domain' ),
		'archives'              => __( 'Item Archives', 'text_domain' ),
		'attributes'            => __( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
		'all_items'             => __( 'All Items', 'text_domain' ),
		'add_new_item'          => __( 'Add New Item', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$args = array(
		'label'                 => __( 'Tour', 'text_domain' ),
		'description'           => __( 'Post Type Description', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'tours_post', $args );

}
add_action( 'init', 'tours_post_type', 0 );